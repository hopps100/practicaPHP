<?php
error_reporting(E_ALL);

require_once '../app/Bootstrap.php';
//var_dump($_GET);
//echo "Apliacion MVC. Estamos en index.php <br>";
$app = new Mvc\App\Bootstrap;
