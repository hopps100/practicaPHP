Framework MVC desarrollado en clase
