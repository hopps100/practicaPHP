<?php
    require '../views/header.php';
?>
<div id="content">
    <h1>Tareas desarrolladas</h1>
    <ul>
        <li>MVC</li>
        <li>Url amigables</li>
        <li>Acceso a BBDD: operaiones CRUD/AMBC</li>
        <li>Consultas preparadas</li>
        <li>Transacciones</li>
        <li>Control de errores</li>
        <li>Sesion: login</li>
        <li>Sesión II: cesta de compra</li>
        <li>Validación</li>
        <li>Paginación</li>
        <li>Relacciones BBDD 1:N --> checkbox</li>
        <li>Maestro-detalle</li>
    </ul>
</div>

<?php
    require '../views/footer.php';
?>
