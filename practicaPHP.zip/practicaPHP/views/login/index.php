<?php
    require '../views/header.php';

?>
<div id="content">
	<form method="post" action="/login/in">
    	<label>Nombre de usuario:</label>
    	<input type="text" name="userName"> <br>
    	<input type="submit">	
    </form>
</div>

<?php
    require '../views/footer.php';
?>
