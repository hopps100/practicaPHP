<?php
    require '../views/header.php';
?>
<div id="content">
    Esta es la vista del Index -> index.
</div>

<?php
    require '../views/footer.php';

?>
