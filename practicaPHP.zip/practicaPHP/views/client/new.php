<?php require '../views/header.php'; ?>
<div id="content">
<h1>Alta de cliente</h1>
<form method="post" action="/client/insert">
    <label>Nombre</label>
    <input type="text" name="name"> <br>
    <label>Direccion</label>
    <input type="text" name="address"> <br>
    <label>Telefono</label>
    <input type="text" name="phone"> <br>
    <label>Credito</label>
    <input type="text" name="credit"> <br>
    <label></label>
    <input type="submit" name="Enviar">
</form>
</div>
<?php
    require '../views/footer.php';
?>
