<?php
    require '../views/header.php';
?>
<div id="content">
<h1>Alta de client</h1>
<form method="post" action="/client/update">
    <label>Id</label>
    <input type="text" name="id" readonly="readonly" value="<?php echo $row['id']; ?>"> <br>
    <label>Nombre</label>
    <input type="text" name="name" value="<?php echo $row['name']; ?>"> <br>
    <label>Direccion</label>
    <input type="text" name="adddress" value="<?php echo $row['adddress']; ?>"> <br>
    <label>Telefono</label>
    <input type="text" name="phone" value="<?php echo $row['phone']; ?>"> <br>
    <label>Credito</label>
    <input type="text" name="credit" value="<?php echo $row['credit']; ?>"> <br>
    <label></label>
    <input type="submit" name="Enviar">
</form>
</div>

<?php
    require '../views/footer.php';
?>
