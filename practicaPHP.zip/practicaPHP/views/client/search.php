<?php
    require '../views/header.php';
?>
<div id="content">
    <form method="post" action="/client/search">
    <label>Buscar</label>
    <input type="text" name="search"> <br>
    <label></label>
    <input type="submit" name="Enviar">
</form>
</div>

<?php
    require '../views/footer.php';
?>