<?php


namespace Mvc\Controller;

class Login
{
    public function __construct()
    {
    }

    public function index($arg1, $arg2)
    {
        require '../views/login/index.php';
    }
    
    public function in()
    {
        $name = $_POST['userName'];
        session_start();
        $_SESSION["userName"] = $name;
        header('Location: /index');
    }

    public function out()
    {
        session_destroy();
        session_start();
        $_SESSION["userName"] = "invitado";
        header('Location: /index');
    }
}
