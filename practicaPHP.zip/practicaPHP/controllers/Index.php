<?php

/**
* Clase con información de ayuda
*/
namespace Mvc\Controller;

class Index
{
    public function __construct()
    {
    }
    public function index($arg1, $arg2)
    {
        require '../views/index/index.php';
    }
}
