<?php

/**
* Clase con información de ayuda
*/
namespace Mvc\Controller;

class Help
{
    public function __construct()
    {
    }

    public function index()
    {
        require '../views/help/index.php';
    }
}
