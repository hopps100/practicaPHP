<?php
/**
* Modelo de login
*/
namespace Mvc\Model;

require_once '../app/Model.php';


class Login extends \Mvc\App\Model
{
    public function __construct()
    {
        parent::__construct();
    }
}
