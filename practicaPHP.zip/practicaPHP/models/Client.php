<?php

namespace Mvc\Model;

require_once '../app/Model.php';


class Client extends \Mvc\App\Model
{
    const DB_HOST = "localhost";
    const DB_USER = "usuario";
    const DB_PASS = "usuario";
    const DB_DATABASE = "mvc";

    private $_rows;

    public function __construct()
    {
         parent::__construct();
    }

    public function get()
    {

        $sql = "select * from client limit";
        $stmt = $this->_pdo->prepare($sql);
        $stmt->execute();
        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        return $rows;
    }

    public function getById($id)
    {
        $sql = "select * from client where id=$id";
        $stmt = $this->_pdo->prepare($sql);
        $stmt->execute();
        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        return $rows;
    }

    public function getRows()
    {
        return $this->_rows;
    }

    public function delete($id)
    {
        $sql = "delete from client where id = $id";
        $stmt = $this->_pdo->prepare($sql);
        $stmt->execute();
    }

    public function new()
    {
        $sql = "insert into user(name, surname, login, password) values(:name, :surname, :login, :password)";
        $stmt = $this->_pdo->prepare($sql);
        $stmt->bindValue(':name', $_POST['name']);
        $stmt->bindValue(':address', $_POST['address']);
        $stmt->bindValue(':phone', $_POST['phone']);
        $stmt->bindValue(':credit', ($_POST['credit']));
        $stmt->execute();
    }
    public function update()
    {
        $sql = "update  client set name='$_POST[name]', adddress='$_POST[adddress]', phone='$_POST[phone]', credit='$_POST[credit]' where id=$_POST[id]";
        $this->_pdo->query($sql);

    }
    public function search($word)
    {
        $sql = "select * from client where name like '%$word%'";
        $stmt = $this->_pdo->prepare($sql);
        $stmt->execute();
        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        return $rows;
    }
}
